﻿using Converencia.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
	/// <summary>
	/// Логика взаимодействия для Authorization.xaml
	/// </summary>
	public partial class Authorization : Page
	{
		public Authorization()
		{
			InitializeComponent();
			login.Text = "";
			password.Password = "";
		}
		private void btnenter_Click(object sender, RoutedEventArgs e)
		{

			if (login.Text == "") MessageBox.Show("Заполните поле логин", "Ошибка ввода данных", MessageBoxButton.OK, MessageBoxImage.Error);
			if (password.Password == "") MessageBox.Show("Заполните поле пароль", "Ошибка ввода данных", MessageBoxButton.OK, MessageBoxImage.Error);
			else
			{
				Participants participants = ClassFrame.db.Participants.FirstOrDefault(x => x.Email == login.Text && x.Pasword == password.Password);
				Moderators moderators = ClassFrame.db.Moderators.FirstOrDefault(x => x.Email == login.Text && x.Pasword == password.Password);
				Jury jury = ClassFrame.db.Jury.FirstOrDefault(x => x.Email == login.Text && x.Pasword == password.Password);
				Organizers organizers = ClassFrame.db.Organizers.FirstOrDefault(x => x.Email == login.Text && x.Pasword == password.Password);
				if (participants != null)
				{
					Users _user = new Users(participants);
					ClassFrame.frmObj.Navigate(new Menu());
				}
				else if (moderators != null)
				{
					Users _user = new Users(moderators);
					ClassFrame.frmObj.Navigate(new Menu());
				}
				else if (jury != null)
				{
					Users _user = new Users(jury);
					ClassFrame.frmObj.Navigate(new Menu());
				}
				else if(organizers != null)
				{
					Users _user = new Users(organizers);
					ClassFrame.frmObj.Navigate(new Menu());
				}
				if (participants == null && organizers == null && jury == null && organizers == null)
					MessageBox.Show("Неверный логин или пароль", "Ошибка ввода данных", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void btnregistration_Click(object sender, RoutedEventArgs e)
		{
			//ClassFrame.frmObj.Navigate(new PageRegistration());
		}
	}
}
