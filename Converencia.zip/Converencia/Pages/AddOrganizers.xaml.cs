﻿using Converencia.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using static System.Net.Mime.MediaTypeNames;


namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddOrganizers.xaml
    /// </summary>
    public partial class AddOrganizers : Page
    {
        private Organizers _currentOrganizers = new Organizers();
        string imgLoc = "пусто";
        public AddOrganizers(Organizers selectedOrganizers)
        {
            InitializeComponent();
            CMBPol.ItemsSource = ConferenceEntities.GetContext().Pol.ToList();
            CMBPol.SelectedValuePath = "IDPol";
            CMBPol.DisplayMemberPath = "NazvaniePol";
            CMBCountry.ItemsSource = ConferenceEntities.GetContext().Country.ToList();
            CMBCountry.SelectedValuePath = "IDCountry";
            CMBCountry.DisplayMemberPath = "NazvanieCountry";

            if (selectedOrganizers != null)
            {
                _currentOrganizers = selectedOrganizers;
            }
            DataContext = _currentOrganizers;
        }
        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentOrganizers.FIO)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(_currentOrganizers.Email)) error.AppendLine("Укажите логин");
            if (string.IsNullOrWhiteSpace(_currentOrganizers.DateOfBirth.ToString())) error.AppendLine("Укажите дату рождения");
            if (string.IsNullOrWhiteSpace(_currentOrganizers.Country.NameCountry)) error.AppendLine("Укажите название страны");
            if (string.IsNullOrWhiteSpace(_currentOrganizers.Phone)) error.AppendLine("Укажите номер телефона");
            if (string.IsNullOrWhiteSpace(_currentOrganizers.Pasword)) error.AppendLine("Укажите пароль");
            if (string.IsNullOrWhiteSpace(_currentOrganizers.Pol.NamePol)) error.AppendLine("Укажите пол");
                
            if (string.IsNullOrWhiteSpace(_currentOrganizers.IDPol.ToString())) error.AppendLine("Укажите пол");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentOrganizers.IDOrganizers == 0)
            {
                ConferenceEntities.GetContext().Organizers.Add(_currentOrganizers);
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        string filename = imgLoc.Substring(imgLoc.LastIndexOf('\\') + 1);
                        _currentOrganizers.Photo = String.Concat("/Photo/foto/", filename);
                    }
                    if (imgLoc == "пусто") _currentOrganizers.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new OrganizersList());
                    MessageBox.Show("Новый организатор успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentOrganizers.Photo = imgLoc;
                    }
                    if (imgLoc == "пусто") _currentOrganizers.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new OrganizersList());
                    MessageBox.Show("Организатор успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new OrganizersList());
        }
        private void ImageLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*",
                    Title = "Выберите фото/изображение лекарства"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageMedicament.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
