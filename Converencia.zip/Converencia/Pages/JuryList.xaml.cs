﻿using Converencia.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для JuryList.xaml
    /// </summary>
    public partial class JuryList : Page
    {
        public JuryList()
        {
            InitializeComponent();
            foreach (var item in dtgJury.Items)
                MessageBox.Show(item.ToString());

            dtgJury.Items.Clear();
            dtgJury.ItemsSource = ConferenceEntities.GetContext().Jury.ToList();
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Menu());
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                dtgJury.ItemsSource = ClassFrame.db.Jury.Where(x => x.FIO.Contains(txtSearch.Text.ToLower()) || x.Country.NameCountry.Contains(txtSearch.Text.ToLower()) || x.Email.Contains(txtSearch.Text.ToLower())).ToList();
            else dtgJury.ItemsSource = ClassFrame.db.Jury.ToList();
        }
        private void MenuDelet_Click(object sender, RoutedEventArgs e)
        {
            var usersForRemoving = dtgJury.SelectedItems.Cast<Jury>().ToList();
            if (MessageBox.Show($"Удалить {usersForRemoving.Count()} жюри?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    ConferenceEntities.GetContext().Jury.RemoveRange(usersForRemoving);
                    ConferenceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    dtgJury.ItemsSource = ConferenceEntities.GetContext().Jury.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }

        }
        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddJury(null));
        }
        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddJury((Jury)dtgJury.SelectedItem));
        }
    }
}
