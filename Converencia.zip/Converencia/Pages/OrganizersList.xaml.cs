﻿using Converencia.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrganizersList.xaml
    /// </summary>
    public partial class OrganizersList : Page
    {
        public OrganizersList()
        {
            InitializeComponent();
            foreach (var item in dtgOrganizers.Items)
                MessageBox.Show(item.ToString());

            dtgOrganizers.Items.Clear();
            dtgOrganizers.ItemsSource = ConferenceEntities.GetContext().Organizers.ToList();

        }

        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Menu());
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                dtgOrganizers.ItemsSource = ClassFrame.db.Organizers.Where(x => x.FIO.Contains(txtSearch.Text.ToLower()) || x.Country.NameCountry.Contains(txtSearch.Text.ToLower()) || x.Email.Contains(txtSearch.Text.ToLower())).ToList();
            else dtgOrganizers.ItemsSource = ClassFrame.db.Organizers.ToList();
        }
         private void MenuDelet_Click(object sender, RoutedEventArgs e)
         {
                var usersForRemoving = dtgOrganizers.SelectedItems.Cast<Organizers>().ToList();
                if (MessageBox.Show($"Удалить {usersForRemoving.Count()} организатора?",
                    "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                    try
                    {
                        ConferenceEntities.GetContext().Organizers.RemoveRange(usersForRemoving);
                        ConferenceEntities.GetContext().SaveChanges();
                        MessageBox.Show("Данные удалены");
                        dtgOrganizers.ItemsSource = ConferenceEntities.GetContext().Organizers.ToList();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }

        }
    }
}
