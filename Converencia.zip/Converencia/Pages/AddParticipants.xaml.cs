﻿using Converencia.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddParticipants.xaml
    /// </summary>
    public partial class AddParticipants : Page
    {
        private Participants _currentParticipants = new Participants();
        string imgLoc = "пусто";
        public AddParticipants(Participants selectedParticipants)
        {
            InitializeComponent();
            CMBPol.ItemsSource = ConferenceEntities.GetContext().Pol.ToList();
            CMBPol.SelectedValuePath = "IDPol";
            CMBPol.DisplayMemberPath = "NamePol";
            CMBCountry.ItemsSource = ConferenceEntities.GetContext().Country.ToList();
            CMBCountry.SelectedValuePath = "IDCountry";
            CMBCountry.DisplayMemberPath = "NameCountry";

            if (selectedParticipants != null)
            {
                _currentParticipants = selectedParticipants;
            }
            DataContext = _currentParticipants;
        }
        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentParticipants.FIO)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(_currentParticipants.Email)) error.AppendLine("Укажите логин");
            if (string.IsNullOrWhiteSpace(_currentParticipants.DateOfBirth.ToString())) error.AppendLine("Укажите дату рождения");
            if (string.IsNullOrWhiteSpace(_currentParticipants.Phone)) error.AppendLine("Укажите номер телефона");
            if (string.IsNullOrWhiteSpace(_currentParticipants.Pasword)) error.AppendLine("Укажите пароль");

            if (string.IsNullOrWhiteSpace(_currentParticipants.IDPol.ToString())) error.AppendLine("Укажите пол");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentParticipants.IDParticipants == 0)
            {
                ConferenceEntities.GetContext().Participants.Add(_currentParticipants);
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        string filename = imgLoc.Substring(imgLoc.LastIndexOf('\\') + 1);
                        _currentParticipants.Photo = String.Concat("/Photo/", filename);
                    }
                    if (imgLoc == "пусто") _currentParticipants.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ParticipantsList());
                    MessageBox.Show("Новый участник успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentParticipants.Photo = imgLoc;
                    }
                    if (imgLoc == "пусто") _currentParticipants.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ParticipantsList());
                    MessageBox.Show("Участник успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ParticipantsList());
        }
        private void PhotoLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*",
                    Title = "Выберите фото/изображение организатора"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageParticipants.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
