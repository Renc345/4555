﻿using Converencia.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddActivites.xaml
    /// </summary>
    public partial class AddActivites : Page
    {
        private Activities _currentActivities = new Activities();
        public AddActivites(Activities selectedActivities)
        {
            InitializeComponent();
            CMBEvent.ItemsSource = ConferenceEntities.GetContext().Event.ToList();
            CMBEvent.SelectedValuePath = "IDEvent";
            CMBEvent.DisplayMemberPath = "NameEvent";
            CMBOrganizers.ItemsSource = ConferenceEntities.GetContext().Organizers.ToList();
            CMBOrganizers.SelectedValuePath = "IDOrganizers";
            CMBOrganizers.DisplayMemberPath = "FIO";
            CMBModerators.ItemsSource = ConferenceEntities.GetContext().Moderators.ToList();
            CMBModerators.SelectedValuePath = "IDModerators";
            CMBModerators.DisplayMemberPath = "FIO";
            CMBJury.ItemsSource = ConferenceEntities.GetContext().Jury.ToList();
            CMBJury.SelectedValuePath = "IDJury";
            CMBJury.DisplayMemberPath = "FIO";
            CMBParticipants.ItemsSource = ConferenceEntities.GetContext().Participants.ToList();
            CMBParticipants.SelectedValuePath = "IDParticipants";
            CMBParticipants.DisplayMemberPath = "FIO";

            if (selectedActivities != null)
            {
                _currentActivities = selectedActivities;
            }
            DataContext = _currentActivities;
        }
        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (_currentActivities.IDJury == 0)
            {
                ConferenceEntities.GetContext().Activities.Add(_currentActivities);
                try
                {
                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ActivitesList());
                    MessageBox.Show("Новый активность успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ActivitesList());
                    MessageBox.Show("Активность успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ActivitesList());
        }
    }
}
