﻿using Converencia.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для PersonalAccount.xaml
    /// </summary>
    public partial class PersonalAccount : Page
    {
        Participants _currentUser = ClassFrame.db.Participants.FirstOrDefault(x => x.IDParticipants == Users.GetUsers.ID);
        Jury _currentUser1 = ClassFrame.db.Jury.FirstOrDefault(x => x.IDJury == Users.GetUsers.ID);
        Organizers _currentUser2 = ClassFrame.db.Organizers.FirstOrDefault(x => x.IDOrganizers == Users.GetUsers.ID);
        Moderators _currentUser3 = ClassFrame.db.Moderators.FirstOrDefault(x => x.IDModerators == Users.GetUsers.ID);
        public PersonalAccount()
        {
            InitializeComponent();
            DataContext = Users.GetUsers;
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Menu());
        }

        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    Users.GetUsers.FIO = textBox.Text;
                    txtFIO1.Visibility = Visibility.Hidden;
                    _currentUser.FIO = textBox.Text;
                }
                if (textBox.Name == "txtLogin1")
                {
                    Users.GetUsers.Email = textBox.Text;
                    txtLogin1.Visibility = Visibility.Hidden;
                    _currentUser.Email = textBox.Text;
                }
                if (textBox.Name == "txtPasword1")
                {
                    Users.GetUsers.Pasword = textBox.Text;
                    txtPasword1.Visibility = Visibility.Hidden;
                    _currentUser.Pasword = textBox.Text;
                }
                ClassFrame.db.SaveChanges();
            }
            if (e.Key == Key.Enter)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    Users.GetUsers.FIO = textBox.Text;
                    txtFIO1.Visibility = Visibility.Hidden;
                    _currentUser1.FIO = textBox.Text;
                }
                if (textBox.Name == "txtLogin1")
                {
                    Users.GetUsers.Email = textBox.Text;
                    txtLogin1.Visibility = Visibility.Hidden;
                    _currentUser1.Email = textBox.Text;
                }
                if (textBox.Name == "txtPasword1")
                {
                    Users.GetUsers.Pasword = textBox.Text;
                    txtPasword1.Visibility = Visibility.Hidden;
                    _currentUser1.Pasword = textBox.Text;
                }
                ClassFrame.db.SaveChanges();
            }
            if (e.Key == Key.Enter)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    Users.GetUsers.FIO = textBox.Text;
                    txtFIO1.Visibility = Visibility.Hidden;
                    _currentUser2.FIO = textBox.Text;
                }
                if (textBox.Name == "txtLogin1")
                {
                    Users.GetUsers.Email = textBox.Text;
                    txtLogin1.Visibility = Visibility.Hidden;
                    _currentUser2.Email = textBox.Text;
                }
                if (textBox.Name == "txtPasword1")
                {
                    Users.GetUsers.Pasword = textBox.Text;
                    txtPasword1.Visibility = Visibility.Hidden;
                    _currentUser2.Pasword = textBox.Text;
                }
                ClassFrame.db.SaveChanges();
            }
            if (e.Key == Key.Enter)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    Users.GetUsers.FIO = textBox.Text;
                    txtFIO1.Visibility = Visibility.Hidden;
                    _currentUser3.FIO = textBox.Text;
                }
                if (textBox.Name == "txtLogin1")
                {
                    Users.GetUsers.Email = textBox.Text;
                    txtLogin1.Visibility = Visibility.Hidden;
                    _currentUser3.Email = textBox.Text;
                }
                if (textBox.Name == "txtPasword1")
                {
                    Users.GetUsers.Pasword = textBox.Text;
                    txtPasword1.Visibility = Visibility.Hidden;
                    _currentUser3.Pasword = textBox.Text;
                }
                ClassFrame.db.SaveChanges();
            }
            if (e.Key == Key.LeftCtrl)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    textBox.Text = _currentUser.FIO;
                    txtFIO1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtLogin1")
                {
                    textBox.Text = _currentUser.Email;
                    txtLogin1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtPasword1")
                {
                    textBox.Text = _currentUser.Pasword;
                    txtPasword1.Visibility = Visibility.Hidden;
                }
            }
            if (e.Key == Key.LeftCtrl)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    textBox.Text = _currentUser1.FIO;
                    txtFIO1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtLogin1")
                {
                    textBox.Text = _currentUser1.Email;
                    txtLogin1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtPasword1")
                {
                    textBox.Text = _currentUser1.Pasword;
                    txtPasword1.Visibility = Visibility.Hidden;
                }
            }
            if (e.Key == Key.LeftCtrl)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    textBox.Text = _currentUser2.FIO;
                    txtFIO1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtLogin1")
                {
                    textBox.Text = _currentUser2.Email;
                    txtLogin1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtPasword1")
                {
                    textBox.Text = _currentUser2.Pasword;
                    txtPasword1.Visibility = Visibility.Hidden;
                }
            }
            if (e.Key == Key.LeftCtrl)
            {
                TextBox textBox = e.Source as TextBox;
                if (textBox.Name == "txtFIO1")
                {
                    textBox.Text = _currentUser3.FIO;
                    txtFIO1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtLogin1")
                {
                    textBox.Text = _currentUser3.Email;
                    txtLogin1.Visibility = Visibility.Hidden;
                }
                if (textBox.Name == "txtPasword1")
                {
                    textBox.Text = _currentUser3.Pasword;
                    txtPasword1.Visibility = Visibility.Hidden;
                }
            }
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                TextBlock textBlock = sender as TextBlock;
                if (textBlock.Name == "txtFIO")
                {
                    txtFIO1.Visibility = Visibility.Visible;
                    txtFIO1.CaretIndex = txtFIO1.Text.Length;
                    txtFIO1.Focus();
                }
                if (textBlock.Name == "txtLogin")
                {
                    txtLogin1.Visibility = Visibility.Visible;
                    txtLogin1.CaretIndex = txtLogin1.Text.Length;
                    txtLogin1.Focus();
                }
                if (textBlock.Name == "txtPasword")
                {
                    txtPasword1.Visibility = Visibility.Visible;
                    txtPasword1.CaretIndex = txtPasword1.Text.Length;
                    txtPasword1.Focus();
                }
            }

        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Authorization());
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Menu());
        }
    }
}
